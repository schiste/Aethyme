#!/usr/bin/env python3
"""Prepare an exact-source final CLI build receipt. PREPARED ONLY; do not run without grant."""
from __future__ import annotations

import argparse
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
from typing import Any

ROOT = Path("/Volumes/T7-repositories/Application Support/Aethyme/worktrees/aethyme-6f13a03e16f294c6/complete-final-combined-local-qualificat")
GIT = Path("/opt/homebrew/bin/git")
RECORDER_REL = Path("target/local-resume/record-final-local-check-v2.py")
RECORDER_SHA256 = "29d2319c55cea24d6a1c76d7038b4bfd96cc105ae17e7ef4c00ef927d19286bc"
TARGET_DIR = Path("/Volumes/T7-repositories/Application Support/Aethyme/worktrees/aethyme-6f13a03e16f294c6/integrate-reviewed-local-bare-git-servic/target/local-resume/cargo")
CLI = TARGET_DIR / "debug/aethyme"
ENGINE = TARGET_DIR / "debug/aethyme-engine-cli"
HOME = Path("/Users/christophehenner")
CARGO_HOME = HOME / ".cargo"
RUSTUP_HOME = HOME / ".rustup"
PATH_VALUE = f"/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin:{CARGO_HOME}/bin"
CLI_RECEIPT_SCHEMA = "aethyme.local-cli-build-command-receipt/v1"
ENGINE_MANIFEST_SCHEMA = "aethyme.local-engine-cli-build-artifact/v1"
BUILD_ARGV = [
    "cargo", "build", "--locked", "-j4",
    "--manifest-path", "packages/aethyme/rust/Cargo.toml",
    "-p", "aethyme-cli", "--bin", "aethyme",
    "-p", "aethyme-engine", "--bin", "aethyme-engine-cli",
]
HEX40 = re.compile(r"[0-9a-f]{40}\Z")
HEX64 = re.compile(r"[0-9a-f]{64}\Z")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def write_exclusive(path: Path, data: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(path, flags, mode)
    try:
        with os.fdopen(fd, "wb", closefd=False) as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
    finally:
        os.close(fd)


def write_json_exclusive(path: Path, value: Any, mode: int = 0o600) -> bytes:
    raw = (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
    write_exclusive(path, raw, mode)
    return raw


def git(*args: str) -> str:
    completed = subprocess.run(
        [str(GIT), "-C", str(ROOT), *args], stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        env={"PATH": PATH_VALUE, "HOME": str(HOME), "GIT_OPTIONAL_LOCKS": "0"},
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(f"git {args!r} exited {completed.returncode}: {completed.stderr.decode('utf-8', 'replace')}")
    return completed.stdout.decode("utf-8", "strict").rstrip("\n")


def source_snapshot() -> dict[str, str]:
    top = Path(git("rev-parse", "--show-toplevel")).resolve(strict=True)
    if top != ROOT.resolve(strict=True):
        raise RuntimeError(f"unexpected worktree top-level: {top}")
    return {
        "path": str(top),
        "head": git("rev-parse", "HEAD"),
        "tree": git("rev-parse", "HEAD^{tree}"),
        "status": git("status", "--porcelain=v1", "--untracked-files=all"),
    }


def regular_binary(path: Path) -> dict[str, Any]:
    if not path.is_absolute() or path.is_symlink():
        raise RuntimeError(f"binary must be an absolute nonsymlink path: {path}")
    resolved = path.resolve(strict=True)
    info = resolved.lstat()
    if not stat.S_ISREG(info.st_mode) or not os.access(resolved, os.X_OK):
        raise RuntimeError(f"binary is not a regular executable: {resolved}")
    digest = hashlib.sha256()
    with resolved.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return {"path": str(resolved), "bytes": info.st_size, "mode": stat.S_IMODE(info.st_mode), "sha256": digest.hexdigest()}


def validate_source_pair(before: dict[str, Any], after: dict[str, Any], head: str, tree: str) -> None:
    if before.get("head") != head or after.get("head") != head:
        raise RuntimeError("recorder source HEAD does not match the explicit expected HEAD")
    if before.get("tree") != tree or after.get("tree") != tree:
        raise RuntimeError("recorder source tree does not match the explicit expected tree")
    if before.get("status") != "" or after.get("status") != "":
        raise RuntimeError("source worktree was not clean before and after the command")
    if before != after:
        raise RuntimeError("source snapshot changed during the command")


def sanitized_env() -> dict[str, str]:
    return {
        "HOME": str(HOME),
        "PATH": PATH_VALUE,
        "CARGO_HOME": str(CARGO_HOME),
        "RUSTUP_HOME": str(RUSTUP_HOME),
        "RUSTC_WRAPPER": "",
        "CARGO_TARGET_DIR": str(TARGET_DIR),
        "CARGO_BUILD_JOBS": "4",
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "TZ": "UTC",
    }


def run_frozen_recorder(
    run_root: Path, recorder_copy: Path, label: str, command: list[str],
) -> dict[str, Any]:
    output_root = run_root / "recorder" / label
    wrapper_dir = run_root / "wrapper" / label
    wrapper_dir.mkdir(mode=0o700, parents=True, exist_ok=False)
    argv = [
        sys.executable, str(recorder_copy),
        "--root", str(ROOT), "--label", label, "--cwd", str(ROOT),
        "--output-root", str(output_root), "--tmp-base", "/private/tmp",
        "--", *command,
    ]
    started = utc_now()
    wrapper = subprocess.run(
        argv, cwd=ROOT, env=sanitized_env(), stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
    )
    ended = utc_now()
    write_exclusive(wrapper_dir / "stdout", wrapper.stdout)
    write_exclusive(wrapper_dir / "stderr", wrapper.stderr)
    write_exclusive(wrapper_dir / "status", f"{wrapper.returncode}\n".encode("ascii"))
    final_record = None
    for line in wrapper.stdout.splitlines():
        try:
            item = json.loads(line.decode("utf-8", "strict"))
        except (UnicodeError, json.JSONDecodeError):
            continue
        if isinstance(item, dict) and item.get("metadata") and item.get("state") != "running":
            final_record = item
    result: dict[str, Any] = {
        "label": label, "argv": argv, "cwd": str(ROOT),
        "started_at_utc": started, "finished_at_utc": ended,
        "recorder_exit_status": wrapper.returncode,
        "wrapper_stdout": str(wrapper_dir / "stdout"), "wrapper_stdout_sha256": sha(wrapper.stdout),
        "wrapper_stderr": str(wrapper_dir / "stderr"), "wrapper_stderr_sha256": sha(wrapper.stderr),
        "wrapper_status": str(wrapper_dir / "status"),
        "recorder_final_line": final_record,
    }
    if final_record is None:
        result["error"] = "frozen recorder produced no completed JSON record; raw wrapper output retained"
        return result
    paths = {key: Path(final_record[key]).resolve(strict=True) for key in ("metadata", "log", "status")}
    for key, path in paths.items():
        try:
            path.relative_to(output_root.resolve(strict=True))
        except ValueError as error:
            raise RuntimeError(f"recorder {key} path escaped this proposal run: {path}") from error
    metadata_bytes = paths["metadata"].read_bytes()
    metadata = json.loads(metadata_bytes.decode("utf-8", "strict"))
    log_bytes = paths["log"].read_bytes()
    status_bytes = paths["status"].read_bytes()
    result["metadata_path"] = str(paths["metadata"])
    result["metadata_sha256"] = sha(metadata_bytes)
    result["metadata"] = metadata
    result["log_path"] = str(paths["log"])
    result["log_bytes"] = len(log_bytes)
    result["log_sha256"] = sha(log_bytes)
    result["status_path"] = str(paths["status"])
    result["status_bytes"] = len(status_bytes)
    result["status_sha256"] = sha(status_bytes)
    if metadata.get("schema") != "aethyme.local-check/v1":
        result["error"] = "unexpected frozen recorder metadata schema"
    elif metadata.get("argv") != command or metadata.get("working_directory") != str(ROOT):
        result["error"] = "recorder metadata does not match exact requested argv/cwd"
    elif metadata.get("numeric_exit") != final_record.get("numeric_exit"):
        result["error"] = "recorder final JSON and command metadata disagree on exit status"
    elif metadata.get("log_sha256") != result["log_sha256"] or metadata.get("log_bytes") != len(log_bytes):
        result["error"] = "recorder log does not match its command metadata"
    elif metadata.get("status_sha256") != result["status_sha256"] or metadata.get("status_bytes") != len(status_bytes):
        result["error"] = "recorder status does not match its command metadata"
    return result


def run_version(
    run_root: Path, name: str, binary: dict[str, Any], expected_head: str,
) -> dict[str, Any]:
    folder = run_root / "versions" / name
    folder.mkdir(mode=0o700, parents=True, exist_ok=False)
    before = source_snapshot()
    started = utc_now()
    start = time.monotonic()
    timed_out = False
    try:
        completed = subprocess.run(
            [binary["path"], "--version"], cwd=ROOT, env={**sanitized_env(), "TMPDIR": str(run_root / "tmp")},
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=30, check=False,
        )
        stdout, stderr, rc = completed.stdout, completed.stderr, completed.returncode
    except subprocess.TimeoutExpired as error:
        timed_out = True
        stdout = error.stdout or b""
        stderr = error.stderr or b""
        if isinstance(stdout, str): stdout = stdout.encode()
        if isinstance(stderr, str): stderr = stderr.encode()
        rc = None
    ended = utc_now()
    after = source_snapshot()
    write_exclusive(folder / "stdout", stdout)
    write_exclusive(folder / "stderr", stderr)
    record = {
        "argv": [binary["path"], "--version"], "cwd": str(ROOT),
        "started_at_utc": started, "finished_at_utc": ended,
        "duration_seconds": round(time.monotonic() - start, 6),
        "timeout_seconds": 30, "timed_out": timed_out, "numeric_exit_status": rc,
        "source_before": before, "source_after": after,
        "source_unchanged": before == after,
        "stdout": {"path": str(folder / "stdout"), "bytes": len(stdout), "sha256": sha(stdout)},
        "stderr": {"path": str(folder / "stderr"), "bytes": len(stderr), "sha256": sha(stderr)},
        "expected_head_in_stdout": expected_head.encode("ascii") in stdout,
    }
    write_json_exclusive(folder / "command.json", record)
    if not timed_out:
        validate_source_pair(before, after, expected_head, record["source_before"]["tree"])
    if rc != 0 or timed_out:
        raise RuntimeError(f"{name} --version did not exit zero within 30 seconds")
    if name == "cli" and not record["expected_head_in_stdout"]:
        raise RuntimeError("aethyme --version output does not contain the full expected HEAD")
    return record


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-head", required=True, help="exact final source HEAD (40 lowercase hex)")
    parser.add_argument("--expected-tree", required=True, help="exact final source tree (40 lowercase hex)")
    parser.add_argument("--run-after-independent-review-and-coordinator-runtime-grant", action="store_true",
                        help="mandatory authorization gate; this driver is prepared-only until granted")
    args = parser.parse_args()
    if not args.run_after_independent_review_and_coordinator_runtime_grant:
        parser.error("runtime grant acknowledgment is mandatory; no build or binary command was started")
    if not HEX40.fullmatch(args.expected_head) or not HEX40.fullmatch(args.expected_tree):
        parser.error("expected HEAD/tree must each be 40 lowercase hexadecimal characters")

    run_root = Path(tempfile.mkdtemp(prefix=f"aethyme-final-cli-build-{args.expected_head[:12]}-", dir="/private/tmp")).resolve(strict=True)
    os.chmod(run_root, 0o700)
    (run_root / "tmp").mkdir(mode=0o700)
    result: dict[str, Any] = {
        "schema": "aethyme.local-final-cli-build-attempt/v1",
        "status": "PREPARED_ATTEMPT_IN_PROGRESS",
        "run_root": str(run_root),
        "expected_head": args.expected_head,
        "expected_tree": args.expected_tree,
        "root": str(ROOT),
        "build_argv": BUILD_ARGV,
        "target_dir": str(TARGET_DIR),
        "runtime_grant_acknowledged": True,
        "errors": [],
    }
    receipt_path = run_root / "cli-build-receipt-v1.json"
    engine_path = run_root / "engine-binary-manifest-v1.json"
    lock_file = None
    try:
        if not ROOT.is_dir() or ROOT.is_symlink():
            raise RuntimeError(f"required source worktree is absent or symlinked: {ROOT}")
        if not GIT.is_file() or not os.access(GIT, os.X_OK):
            raise RuntimeError(f"fixed Git executable is unavailable: {GIT}")
        for required_dir in (HOME, CARGO_HOME, RUSTUP_HOME, TARGET_DIR):
            if not required_dir.is_dir():
                raise RuntimeError(f"required build directory is unavailable: {required_dir}")
        lock_path = TARGET_DIR / ".aethyme-final-local-validation.lock"
        lock_file = lock_path.open("a+")
        try:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            lock_file.close()
            raise RuntimeError(f"shared Cargo target is already locked: {lock_path}") from error
        process_lines = subprocess.check_output(
            ["/bin/ps", "-A", "-o", "pid=,comm="], env=sanitized_env(), text=True
        ).splitlines()
        compiler_names = {"cargo", "rustc", "rustdoc", "clippy-driver", "cargo-clippy", "cargo-nextest"}
        active = [line for line in process_lines if line.strip() and Path(line.strip().split(None, 1)[1]).name in compiler_names]
        result["shared_target_lock"] = str(lock_path)
        result["preflight_active_compilers"] = active
        if active:
            raise RuntimeError("Cargo/compiler activity exists before the build; no process was stopped")
        source_before = source_snapshot()
        if source_before["head"] != args.expected_head or source_before["tree"] != args.expected_tree:
            raise RuntimeError("current source HEAD/tree do not match the explicit expected pins")
        if source_before["status"]:
            raise RuntimeError("source worktree is dirty before build")
        recorder = ROOT / RECORDER_REL
        if recorder.is_symlink() or not recorder.is_file() or sha(recorder.read_bytes()) != RECORDER_SHA256:
            raise RuntimeError("frozen recorder path/type/SHA-256 does not match its reviewed pin")
        recorder_copy = run_root / "recorder-copy" / recorder.name
        write_exclusive(recorder_copy, recorder.read_bytes(), 0o500)
        if sha(recorder_copy.read_bytes()) != RECORDER_SHA256:
            raise RuntimeError("private frozen recorder copy hash mismatch")
        result["recorder"] = {"source_path": str(recorder), "copy_path": str(recorder_copy), "sha256": RECORDER_SHA256}
        result["source_before"] = source_before

        build = run_frozen_recorder(run_root, recorder_copy, "final-cli-build", BUILD_ARGV)
        result["build_attempt"] = build
        if build.get("error"):
            raise RuntimeError(build["error"])
        metadata = build["metadata"]
        if (metadata.get("state") != "completed" or metadata.get("launcher_error") is not None
                or type(metadata.get("numeric_exit")) is not int or metadata["numeric_exit"] != 0
                or metadata.get("source_unchanged") is not True):
            raise RuntimeError("recorded build did not complete successfully with unchanged source")
        validate_source_pair(metadata["source_before"], metadata["source_after"], args.expected_head, args.expected_tree)
        if (build["recorder_exit_status"] != 0
                or Path(build["status_path"]).read_bytes() != b"0\n"):
            raise RuntimeError("frozen recorder exit/status does not confirm numeric build exit zero")

        cli_info = regular_binary(CLI)
        engine_info = regular_binary(ENGINE)
        cli_version = run_version(run_root, "cli", cli_info, args.expected_head)
        engine_version = run_version(run_root, "engine", engine_info, args.expected_head)
        cli_after_versions = regular_binary(CLI)
        engine_after_versions = regular_binary(ENGINE)
        if cli_after_versions != cli_info or engine_after_versions != engine_info:
            raise RuntimeError("one or both build binaries changed while version receipts were collected")
        source_after = source_snapshot()
        if source_after != source_before:
            raise RuntimeError("source worktree changed during build/version receipts")

        build_receipt = {
            "schema": CLI_RECEIPT_SCHEMA,
            "source": {
                "path": str(ROOT),
                "head_before": metadata["source_before"]["head"],
                "tree_before": metadata["source_before"]["tree"],
                "status_before": metadata["source_before"]["status"],
                "head_after": metadata["source_after"]["head"],
                "tree_after": metadata["source_after"]["tree"],
                "status_after": metadata["source_after"]["status"],
                "unchanged": metadata["source_unchanged"],
            },
            "command": {
                "kind": "aethyme-cli-build",
                "argv": BUILD_ARGV,
                "cwd": str(ROOT),
                "started_at_utc": metadata["started_at_utc"],
                "finished_at_utc": metadata["ended_at_utc"],
                "exit_status": metadata["numeric_exit"],
                "recorder_metadata_path": build["metadata_path"],
                "recorder_metadata_sha256": build["metadata_sha256"],
                "recorder_log_path": build["log_path"],
                "recorder_log_bytes": build["log_bytes"],
                "recorder_log_sha256": build["log_sha256"],
                "recorder_status_path": build["status_path"],
                "recorder_status_sha256": build["status_sha256"],
                "recorder_sha256": RECORDER_SHA256,
            },
            "binary": cli_info,
            "version_receipt": {
                "path": str(run_root / "versions/cli/command.json"),
                "sha256": sha((run_root / "versions/cli/command.json").read_bytes()),
                "stdout_path": cli_version["stdout"]["path"],
                "stdout_sha256": cli_version["stdout"]["sha256"],
                "expected_head_in_stdout": cli_version["expected_head_in_stdout"],
            },
        }
        receipt_bytes = write_json_exclusive(receipt_path, build_receipt, 0o400)
        os.chmod(receipt_path, 0o444)
        engine_manifest = {
            "schema": ENGINE_MANIFEST_SCHEMA,
            "source": build_receipt["source"],
            "build_command_receipt": {"path": str(receipt_path), "bytes": len(receipt_bytes), "sha256": sha(receipt_bytes)},
            "binary": engine_info,
            "version_receipt": {
                "path": str(run_root / "versions/engine/command.json"),
                "sha256": sha((run_root / "versions/engine/command.json").read_bytes()),
                "stdout_path": engine_version["stdout"]["path"],
                "stdout_sha256": engine_version["stdout"]["sha256"],
            },
        }
        engine_bytes = write_json_exclusive(engine_path, engine_manifest, 0o400)
        os.chmod(engine_path, 0o444)
        result.update({
            "status": "PASS_BUILD_RECEIPTS_READY",
            "source_after": source_after,
            "cli_binary": cli_info,
            "engine_binary": engine_info,
            "cli_version": cli_version,
            "engine_version": engine_version,
            "cli_build_receipt": {"path": str(receipt_path), "bytes": len(receipt_bytes), "sha256": sha(receipt_bytes)},
            "engine_binary_manifest": {"path": str(engine_path), "bytes": len(engine_bytes), "sha256": sha(engine_bytes)},
        })
    except BaseException as error:
        result["status"] = "UNQUALIFIED_BUILD_OR_RECEIPT_FAILURE"
        result["errors"].append(f"{type(error).__name__}: {error}")
        try:
            result["source_after"] = source_snapshot()
        except BaseException as snapshot_error:
            result["source_after_error"] = f"{type(snapshot_error).__name__}: {snapshot_error}"
    finally:
        if lock_file is not None and not lock_file.closed:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
            lock_file.close()
    summary = run_root / "attempt-summary.json"
    write_json_exclusive(summary, result)
    print(json.dumps({"status": result["status"], "run_root": str(run_root),
                      "cli_build_receipt": result.get("cli_build_receipt"),
                      "engine_binary_manifest": result.get("engine_binary_manifest"),
                      "errors": result["errors"]}, sort_keys=True))
    return 0 if result["status"] == "PASS_BUILD_RECEIPTS_READY" else 1


if __name__ == "__main__":
    sys.exit(main())
