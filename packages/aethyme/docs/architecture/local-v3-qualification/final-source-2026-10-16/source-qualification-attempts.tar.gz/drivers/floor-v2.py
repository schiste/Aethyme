#!/usr/bin/env python3
"""Prepare and run a private, local-only schema-26/old-schema-23 refusal check.

This script does not compile/install Aethyme or contact a provider/service.
It requires an already-built exact new CLI and an unchanged clean source tree.
All generated Git repositories, collaboration state, command receipts, and raw
outputs stay in one fresh /private/tmp directory and are retained for review.
The required read-only build receipt binds the exact new CLI bytes to a completed
build of the same clean source HEAD/tree.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import pathlib
import re
import shutil
import sqlite3
import stat
import subprocess
import sys
import tempfile
import time
from typing import Any

PINNED_OLD_CLI = pathlib.Path(
    "/Volumes/T7-repositories/Application Support/Aethyme/worktrees/"
    "aethyme-6f13a03e16f294c6/682-reconcile-final-local-qualification/"
    "target/local-resume/old-state23-cli/aethyme-1d0ce264-state23"
)
PINNED_OLD_SHA256 = "1268402c5d49ac303b61bc28b4e4726bf95b1d17d64d7099850f2f67950f7e6f"
EXPECTED_SCHEMA = 26
EXPECTED_FLOOR = 26
OLD_CLIENT_SCHEMA = 23
PROJECT_KEY = "proj-schema26-floor"
BUILD_RECEIPT_SCHEMA = "aethyme.local-cli-build-command-receipt/v1"
MAX_BUILD_RECEIPT_BYTES = 2 * 1024 * 1024
CONFIG_BYTES = (
    b"[collaboration]\n"
    b'capture = "advisory"\n'
    b'project = "proj-schema26-floor"\n'
)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_json(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode()


def write_exclusive(path: pathlib.Path, data: bytes) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(path, flags, 0o600)
    try:
        with os.fdopen(fd, "wb", closefd=False) as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
    finally:
        os.close(fd)


def binary_info(path: pathlib.Path, expected_sha256: str | None = None) -> dict[str, Any]:
    if not path.is_absolute():
        raise RuntimeError(f"binary path must be absolute: {path}")
    if path.is_symlink():
        raise RuntimeError(f"binary path must not be a symlink: {path}")
    exact = path.resolve(strict=True)
    st = exact.lstat()
    if not stat.S_ISREG(st.st_mode) or stat.S_ISLNK(st.st_mode) or not os.access(exact, os.X_OK):
        raise RuntimeError(f"binary is not a regular executable: {exact}")
    digest = sha256_file(exact)
    if expected_sha256 is not None and digest != expected_sha256:
        raise RuntimeError(f"pinned binary hash mismatch for {exact}: {digest}")
    return {
        "path": str(exact),
        "bytes": st.st_size,
        "mode": stat.S_IMODE(st.st_mode),
        "sha256": digest,
    }


def _unique_json_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise RuntimeError(f"duplicate key in build receipt: {key}")
        result[key] = value
    return result


def read_build_receipt(path: pathlib.Path) -> tuple[bytes, dict[str, Any], dict[str, Any]]:
    """Read one regular, nonsymlink, non-writable receipt without following links.

    V1 contract: schema, source.{path,head_before,tree_before,status_before,
    head_after,tree_after,status_after,unchanged}, command.{kind,argv,cwd,
    started_at_utc,finished_at_utc,exit_status}, and binary.{path,bytes,sha256}.
    """
    if not path.is_absolute():
        raise RuntimeError("--build-receipt must be an absolute path")
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or stat.S_ISLNK(before.st_mode):
        raise RuntimeError(f"build receipt must be a regular nonsymlink file: {path}")
    mode = stat.S_IMODE(before.st_mode)
    if mode & 0o222:
        raise RuntimeError(f"build receipt must be read-only (no write permission bits): {path}")
    if before.st_size <= 0 or before.st_size > MAX_BUILD_RECEIPT_BYTES:
        raise RuntimeError(f"build receipt has invalid byte size: {before.st_size}")
    flags = os.O_RDONLY | getattr(os, "O_NONBLOCK", 0)
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(path, flags)
    try:
        opened = os.fstat(fd)
        if (not stat.S_ISREG(opened.st_mode) or stat.S_ISLNK(opened.st_mode)
                or (opened.st_dev, opened.st_ino, opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns)
                != (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                or stat.S_IMODE(opened.st_mode) & 0o222):
            raise RuntimeError("build receipt changed identity or permissions while opening")
        chunks: list[bytes] = []
        total = 0
        with os.fdopen(fd, "rb", closefd=False) as stream:
            while True:
                block = stream.read(64 * 1024)
                if not block:
                    break
                total += len(block)
                if total > MAX_BUILD_RECEIPT_BYTES:
                    raise RuntimeError("build receipt exceeds the size limit")
                chunks.append(block)
        after = os.fstat(fd)
        current = path.lstat()
        if ((after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
                != (opened.st_dev, opened.st_ino, opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns)
                or (current.st_dev, current.st_ino, current.st_size, current.st_mtime_ns, current.st_ctime_ns)
                != (opened.st_dev, opened.st_ino, opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns)):
            raise RuntimeError("build receipt changed while being read")
    finally:
        os.close(fd)
    raw = b"".join(chunks)
    try:
        receipt = json.loads(raw.decode("utf-8", errors="strict"), object_pairs_hook=_unique_json_object)
    except Exception as error:
        raise RuntimeError(f"build receipt is not strict UTF-8 JSON: {error}") from error
    if not isinstance(receipt, dict) or receipt.get("schema") != BUILD_RECEIPT_SCHEMA:
        raise RuntimeError(f"unsupported build receipt schema; expected {BUILD_RECEIPT_SCHEMA}")
    source = receipt.get("source")
    command = receipt.get("command")
    binary = receipt.get("binary")
    if not all(isinstance(item, dict) for item in (source, command, binary)):
        raise RuntimeError("build receipt source/command/binary sections must be objects")
    if source.get("unchanged") is not True:
        raise RuntimeError("build receipt does not certify unchanged source")
    for field in ("head_before", "tree_before", "head_after", "tree_after"):
        value = source.get(field)
        if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{40}", value):
            raise RuntimeError(f"build receipt source.{field} must be a 40-character lowercase Git id")
    if source["head_before"] != source["head_after"] or source["tree_before"] != source["tree_after"]:
        raise RuntimeError("build receipt source HEAD/tree changed during build")
    if source.get("status_before") != "" or source.get("status_after") != "":
        raise RuntimeError("build receipt source must be clean before and after build")
    if command.get("kind") != "aethyme-cli-build":
        raise RuntimeError("build receipt command.kind must be aethyme-cli-build")
    argv = command.get("argv")
    if not isinstance(argv, list) or not argv or not all(isinstance(arg, str) and arg for arg in argv):
        raise RuntimeError("build receipt command.argv must be a nonempty string array")
    if (not isinstance(command.get("cwd"), str) or not command["cwd"]
            or not isinstance(command.get("started_at_utc"), str) or not command["started_at_utc"]
            or not isinstance(command.get("finished_at_utc"), str) or not command["finished_at_utc"]):
        raise RuntimeError("build receipt command cwd/start/finish metadata is missing")
    exit_status = command.get("exit_status")
    if type(exit_status) is not int or exit_status != 0:
        raise RuntimeError("build receipt command.exit_status must be numeric zero")
    if not isinstance(binary.get("path"), str) or not pathlib.Path(binary["path"]).is_absolute():
        raise RuntimeError("build receipt binary.path must be absolute")
    for field in ("started_at_utc", "finished_at_utc"):
        try:
            parsed = dt.datetime.fromisoformat(command[field].replace("Z", "+00:00"))
        except ValueError as error:
            raise RuntimeError(f"build receipt command.{field} is not an ISO-8601 timestamp") from error
        if parsed.tzinfo is None:
            raise RuntimeError(f"build receipt command.{field} must include a timezone")
    started = dt.datetime.fromisoformat(command["started_at_utc"].replace("Z", "+00:00"))
    finished = dt.datetime.fromisoformat(command["finished_at_utc"].replace("Z", "+00:00"))
    if finished < started:
        raise RuntimeError("build receipt command finished before it started")
    if type(binary.get("bytes")) is not int or binary["bytes"] <= 0:
        raise RuntimeError("build receipt binary.bytes must be a positive integer")
    if not isinstance(binary.get("sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", binary["sha256"]):
        raise RuntimeError("build receipt binary.sha256 must be a lowercase SHA-256")
    metadata = {
        "path": str(path.resolve(strict=True)),
        "bytes": len(raw),
        "sha256": sha256_bytes(raw),
        "mode": mode,
    }
    return raw, receipt, metadata


def validate_build_receipt_binding(
    receipt: dict[str, Any], source_path: pathlib.Path,
    source_snapshot: dict[str, Any], new_cli_info: dict[str, Any],
) -> None:
    source = receipt["source"]
    command = receipt["command"]
    binary = receipt["binary"]
    exact_source = str(source_path.resolve(strict=True))
    if (not isinstance(source.get("path"), str) or not pathlib.Path(source["path"]).is_absolute()
            or source.get("path") != exact_source or command.get("cwd") != exact_source):
        raise RuntimeError("build receipt source path/command cwd does not match --source-repo")
    if source.get("head_before") != source_snapshot["head"] or source.get("head_after") != source_snapshot["head"]:
        raise RuntimeError("build receipt HEAD does not match the unchanged current source HEAD")
    if source.get("tree_before") != source_snapshot["tree"] or source.get("tree_after") != source_snapshot["tree"]:
        raise RuntimeError("build receipt tree does not match the unchanged current source tree")
    if source_snapshot["status"]:
        raise RuntimeError("source worktree is not clean while validating build receipt")
    if (pathlib.Path(binary["path"]).resolve(strict=True) != pathlib.Path(new_cli_info["path"])
            or binary["bytes"] != new_cli_info["bytes"]
            or binary["sha256"] != new_cli_info["sha256"]):
        raise RuntimeError("build receipt does not identify the exact --new-cli path/bytes/SHA-256")


class Recorder:
    def __init__(self, root: pathlib.Path, env_base: dict[str, str], git_bin: pathlib.Path):
        self.root = root
        self.evidence = root / "evidence"
        self.commands = self.evidence / "commands"
        self.commands.mkdir(mode=0o700, parents=True, exist_ok=False)
        self.env_base = env_base
        self.git_bin = git_bin
        self.command_rows: list[dict[str, Any]] = []
        self.data: dict[str, Any] = {}

    def run(
        self,
        label: str,
        argv: list[str],
        cwd: pathlib.Path,
        timeout_s: int = 120,
    ) -> subprocess.CompletedProcess[bytes]:
        if not re.fullmatch(r"[a-z0-9-]+", label):
            raise RuntimeError(f"invalid command label: {label}")
        index = len(self.command_rows) + 1
        stem = f"{index:03d}-{label}"
        stdout_path = self.commands / f"{stem}.stdout"
        stderr_path = self.commands / f"{stem}.stderr"
        record_path = self.commands / f"{stem}.json"
        env = dict(self.env_base)
        env["PWD"] = str(cwd)
        started = dt.datetime.now(dt.timezone.utc).isoformat()
        start_ns = time.monotonic_ns()
        timed_out = False
        try:
            result = subprocess.run(
                argv,
                cwd=cwd,
                env=env,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout_s,
                check=False,
            )
            stdout = result.stdout
            stderr = result.stderr
            exit_status: int | None = result.returncode
        except subprocess.TimeoutExpired as error:
            timed_out = True
            stdout = error.stdout or b""
            stderr = error.stderr or b""
            if isinstance(stdout, str):
                stdout = stdout.encode()
            if isinstance(stderr, str):
                stderr = stderr.encode()
            exit_status = None
            result = subprocess.CompletedProcess(argv, 124, stdout, stderr)
        elapsed_ns = time.monotonic_ns() - start_ns
        write_exclusive(stdout_path, stdout)
        write_exclusive(stderr_path, stderr)
        row = {
            "label": label,
            "argv": argv,
            "cwd": str(cwd),
            "env": dict(sorted(env.items())),
            "started_at_utc": started,
            "timeout_seconds": timeout_s,
            "timed_out": timed_out,
            "exit_status": exit_status,
            "elapsed_ns": elapsed_ns,
            "stdout_path": str(stdout_path.relative_to(self.root)),
            "stdout_bytes": len(stdout),
            "stdout_sha256": sha256_bytes(stdout),
            "stderr_path": str(stderr_path.relative_to(self.root)),
            "stderr_bytes": len(stderr),
            "stderr_sha256": sha256_bytes(stderr),
        }
        write_exclusive(record_path, canonical_json(row))
        self.command_rows.append(row)
        if timed_out:
            raise RuntimeError(f"command timed out after {timeout_s}s: {label}")
        return result

    def git(self, label: str, args: list[str], cwd: pathlib.Path) -> subprocess.CompletedProcess[bytes]:
        return self.run(label, [str(self.git_bin), *args], cwd)

    def expect_zero(self, label: str, result: subprocess.CompletedProcess[bytes]) -> None:
        if result.returncode != 0:
            raise RuntimeError(f"{label} exited {result.returncode}; see evidence/commands")

    def write_snapshot(self, label: str, roots: list[pathlib.Path]) -> tuple[dict[str, Any], str]:
        snapshot: dict[str, Any] = {}
        for root in roots:
            snapshot[str(root)] = inventory_tree(root)
        data = canonical_json(snapshot)
        path = self.evidence / "snapshots" / f"{label}.json"
        write_exclusive(path, data)
        return snapshot, sha256_bytes(data)

    def finish(self, status: str, error: str | None = None) -> pathlib.Path:
        manifest = {
            "schema": "aethyme.schema26-old-schema23-cli-refusal/v1",
            "status": status,
            "error": error,
            "run_root": str(self.root),
            "script": {
                "path": str(pathlib.Path(__file__).resolve()),
                "sha256": sha256_file(pathlib.Path(__file__).resolve()),
            },
            "commands": self.command_rows,
            "results": self.data,
        }
        path = self.evidence / "final-manifest.json"
        write_exclusive(path, canonical_json(manifest))
        return path


def inventory_tree(root: pathlib.Path) -> dict[str, Any]:
    if root.is_symlink():
        raise RuntimeError(f"inventory root must not be a symlink: {root}")
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise RuntimeError(f"inventory root must be a real directory: {root}")
    result: dict[str, Any] = {".": {"kind": "directory", "mode": stat.S_IMODE(root.stat().st_mode)}}
    pending = [root]
    while pending:
        current = pending.pop()
        for entry in sorted(os.scandir(current), key=lambda item: item.name):
            path = pathlib.Path(entry.path)
            rel = path.relative_to(root).as_posix()
            st = path.lstat()
            mode = stat.S_IMODE(st.st_mode)
            if stat.S_ISLNK(st.st_mode):
                result[rel] = {"kind": "symlink", "mode": mode, "target": os.readlink(path)}
            elif stat.S_ISDIR(st.st_mode):
                result[rel] = {"kind": "directory", "mode": mode}
                pending.append(path)
            elif stat.S_ISREG(st.st_mode):
                result[rel] = {
                    "kind": "file",
                    "mode": mode,
                    "bytes": st.st_size,
                    "sha256": sha256_file(path),
                }
            else:
                raise RuntimeError(f"unsupported filesystem object in inventory: {path}")
    return result


def capture_source_git(recorder: Recorder, source: pathlib.Path, label: str) -> dict[str, Any]:
    rows: dict[str, Any] = {}
    for suffix, args in (
        ("head", ["rev-parse", "HEAD"]),
        ("tree", ["rev-parse", "HEAD^{tree}"]),
        ("status", ["status", "--porcelain=v1", "--untracked-files=all"]),
    ):
        result = recorder.git(f"{label}-{suffix}", args, source)
        recorder.expect_zero(f"{label}-{suffix}", result)
        rows[suffix] = result.stdout.decode("utf-8", errors="strict").strip()
    relevant = {}
    for rel in (
        "packages/aethyme/rust/crates/aethyme-broker/src/collaboration_state.rs",
        "packages/aethyme/rust/crates/aethyme-broker/src/collaboration_cli.rs",
        "packages/aethyme/rust/crates/aethyme-broker/src/collaboration_submit.rs",
    ):
        path = source / rel
        data = path.read_bytes()
        relevant[rel] = {"bytes": len(data), "sha256": sha256_bytes(data)}
    state_source = (source / "packages/aethyme/rust/crates/aethyme-broker/src/collaboration_state.rs").read_text()
    if "COLLABORATION_STATE_SCHEMA_VERSION: i64 = 26" not in state_source:
        raise RuntimeError("source does not declare collaboration schema 26")
    if "const MIN_COMPATIBLE_SCHEMA: i64 = 26" not in state_source:
        raise RuntimeError("source does not declare minimum compatible schema 26")
    rows["relevant_source_files"] = relevant
    return rows


def read_db_meta(db: pathlib.Path) -> dict[str, str]:
    if not db.is_file() or db.is_symlink():
        raise RuntimeError(f"expected state database is missing or not regular: {db}")
    uri = db.as_uri() + "?mode=ro"
    connection = sqlite3.connect(uri, uri=True, timeout=2)
    try:
        connection.execute("PRAGMA query_only=ON")
        rows = dict(connection.execute(
            "SELECT key, value FROM meta WHERE key IN "
            "('schema_version', 'min_compatible_schema', 'project_key')"
        ).fetchall())
    finally:
        connection.close()
    return {key: str(value) for key, value in rows.items()}


def git_head_tree(recorder: Recorder, repo: pathlib.Path, label: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for suffix, args in (
        ("head", ["rev-parse", "HEAD"]),
        ("tree", ["rev-parse", "HEAD^{tree}"]),
        ("status", ["status", "--porcelain=v1", "--untracked-files=all"]),
        ("upstream", ["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"]),
    ):
        command = recorder.git(f"{label}-{suffix}", args, repo)
        recorder.expect_zero(f"{label}-{suffix}", command)
        result[suffix] = command.stdout.decode("utf-8", errors="strict").strip()
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--new-cli", required=True, type=pathlib.Path,
                        help="absolute path to the already-built final Aethyme CLI")
    parser.add_argument("--source-repo", required=True, type=pathlib.Path,
                        help="clean source worktree used for the final CLI build")
    parser.add_argument("--build-receipt", required=True, type=pathlib.Path,
                        help="absolute, read-only v1 receipt for the completed exact CLI build")
    args = parser.parse_args()

    os.umask(0o077)
    source = args.source_repo.resolve(strict=True)
    build_receipt_path = args.build_receipt
    build_receipt_bytes, build_receipt, build_receipt_info = read_build_receipt(build_receipt_path)
    if not args.new_cli.is_absolute():
        raise RuntimeError("--new-cli must be an absolute path")
    new_cli_path = args.new_cli
    old_cli_info = binary_info(PINNED_OLD_CLI, PINNED_OLD_SHA256)
    new_cli_info = binary_info(new_cli_path)
    if new_cli_info["path"] == old_cli_info["path"]:
        raise RuntimeError("new CLI must be a distinct exact binary")

    git = shutil.which("git")
    if not git:
        raise RuntimeError("git executable not found")
    git_bin = pathlib.Path(git).resolve(strict=True)

    run_root = pathlib.Path(tempfile.mkdtemp(prefix="aethyme-schema26-old23-", dir="/private/tmp"))
    if run_root.parent != pathlib.Path("/private/tmp") or run_root.is_symlink():
        raise RuntimeError(f"unexpected run root: {run_root}")
    os.chmod(run_root, 0o700)
    playground = run_root / "playground"
    evidence = run_root / "evidence"
    for directory in (playground, evidence):
        directory.mkdir(mode=0o700)
    repo = playground / "repo"
    origin = playground / "origin.git"
    state = playground / "state"
    worktrees = playground / "worktrees"
    cache = playground / "cache"
    tmp = run_root / "tmp"
    hooks = run_root / "empty-git-hooks"
    for directory in (state, worktrees, cache, tmp, hooks):
        directory.mkdir(mode=0o700)
    gitconfig = run_root / "gitconfig"
    write_exclusive(gitconfig, (
        b"[init]\n\tdefaultBranch = main\n"
        b"[user]\n\tname = Schema Floor Probe\n\temail = schema-floor-probe@example.invalid\n"
        b"[core]\n\thooksPath = " + str(hooks).encode() + b"\n"
    ))

    # Strip inherited provider/credential settings. The recorded environment is
    # the complete, intentionally small environment each child actually sees.
    env: dict[str, str] = {}
    for name in ("HOME", "PATH", "LANG", "LC_ALL", "LC_CTYPE", "TERM", "USER", "LOGNAME"):
        if name in os.environ:
            env[name] = os.environ[name]
    if "HOME" not in env or "PATH" not in env:
        raise RuntimeError("HOME and PATH must be present for the local CLI")
    env.update({
        "LANG": "C",
        "LC_ALL": "C",
        "TZ": "UTC",
        "TMPDIR": str(tmp),
        "AETHYME_HOST_STATE_DIR": str(state),
        "AETHYME_HOST_CACHE_DIR": str(cache),
        "AETHYME_WORKTREE_ROOT": str(worktrees),
        "XDG_STATE_HOME": str(state),
        "XDG_CACHE_HOME": str(cache),
        "GIT_CONFIG_GLOBAL": str(gitconfig),
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_TERMINAL_PROMPT": "0",
        "GIT_ALLOW_PROTOCOL": "file",
    })
    recorder = Recorder(run_root, env, git_bin)
    build_receipt_copy = evidence / "inputs" / "build-command-receipt.json"
    write_exclusive(build_receipt_copy, build_receipt_bytes)
    build_receipt_copy_sha = sha256_file(build_receipt_copy)
    if (build_receipt_copy.stat().st_size != build_receipt_info["bytes"]
            or build_receipt_copy_sha != build_receipt_info["sha256"]):
        raise RuntimeError("private build receipt evidence copy failed its byte/SHA-256 check")
    recorder.data["inputs"] = {
        "source_repo": str(source),
        "new_cli": new_cli_info,
        "build_receipt": {
            **build_receipt_info,
            "evidence_copy": str(build_receipt_copy.relative_to(run_root)),
            "evidence_copy_sha256": build_receipt_copy_sha,
            "schema": build_receipt["schema"],
        },
        "old_cli": old_cli_info,
        "git_binary": binary_info(git_bin),
        "pinned_old_cli_source": "t64-cli-bootstrap-2026-10-15/ledger.json:binaries.pinned_schema23_cli",
        "expected": {
            "schema_version": EXPECTED_SCHEMA,
            "min_compatible_schema": EXPECTED_FLOOR,
            "old_client_schema_support": OLD_CLIENT_SCHEMA,
            "project_key": PROJECT_KEY,
        },
        "run_paths": {
            "playground": str(playground),
            "repo": str(repo),
            "origin": str(origin),
            "host_state": str(state),
            "worktrees": str(worktrees),
            "cache": str(cache),
        },
    }
    final_status = "FAIL"
    final_error: str | None = None
    manifest_path: pathlib.Path | None = None
    try:
        source_before = capture_source_git(recorder, source, "source-before")
        if source_before["status"]:
            raise RuntimeError("source worktree is not clean; refusing to associate binary with a dirty tree")
        validate_build_receipt_binding(build_receipt, source, source_before, new_cli_info)
        recorder.data["source_before"] = source_before

        for label, binary in (("new-cli-version", new_cli_info["path"]),
                              ("old-cli-version", old_cli_info["path"])):
            version = recorder.run(label, [binary, "--version"], source)
            recorder.expect_zero(label, version)

        # A local bare origin makes the fixture's legacy-readable config truly
        # committed and available through origin/main. Git protocol is file-only.
        result = recorder.git("git-init-origin", ["init", "--bare", "--initial-branch=main", str(origin)], playground)
        recorder.expect_zero("git-init-origin", result)
        result = recorder.git("git-init-playground", ["init", "--initial-branch=main", str(repo)], playground)
        recorder.expect_zero("git-init-playground", result)
        (repo / ".aethyme").mkdir(mode=0o700)
        write_exclusive(repo / ".aethyme" / "config.toml", CONFIG_BYTES)
        write_exclusive(repo / "README.md", b"Synthetic schema-floor Playground.\n")
        result = recorder.git("git-add-seed", ["add", "--", ".aethyme/config.toml", "README.md"], repo)
        recorder.expect_zero("git-add-seed", result)
        result = recorder.git("git-commit-seed", ["commit", "-m", "chore(local): seed schema floor Playground"], repo)
        recorder.expect_zero("git-commit-seed", result)
        result = recorder.git("git-add-origin", ["remote", "add", "origin", str(origin)], repo)
        recorder.expect_zero("git-add-origin", result)
        result = recorder.git("git-push-main", ["push", "--set-upstream", "origin", "main"], repo)
        recorder.expect_zero("git-push-main", result)
        result = recorder.git("git-set-origin-head", ["remote", "set-head", "origin", "main"], repo)
        recorder.expect_zero("git-set-origin-head", result)
        committed_config = recorder.git(
            "git-read-committed-config", ["show", "origin/main:.aethyme/config.toml"], repo
        )
        recorder.expect_zero("git-read-committed-config", committed_config)
        if committed_config.stdout != CONFIG_BYTES:
            raise RuntimeError("origin/main does not contain the exact seeded legacy config bytes")
        recorder.data["seed_config"] = {
            "path": str(repo / ".aethyme" / "config.toml"),
            "bytes": len(CONFIG_BYTES),
            "sha256": sha256_bytes(CONFIG_BYTES),
            "committed_bytes_equal_working_copy": (repo / ".aethyme" / "config.toml").read_bytes() == CONFIG_BYTES,
            "committed_origin_main_bytes_equal": committed_config.stdout == CONFIG_BYTES,
        }
        repo_before = git_head_tree(recorder, repo, "playground-before-start")
        if repo_before["upstream"] != "origin/main" or repo_before["status"]:
            raise RuntimeError("seed Playground is not clean on committed origin/main")
        recorder.data["playground_before"] = repo_before

        start = recorder.run(
            "new-broker-start",
            [new_cli_info["path"], "broker", "start", "--task", "schema26-old-client-floor-probe",
             "--short-name", "schema26-floor", "--json"],
            repo,
        )
        recorder.expect_zero("new-broker-start", start)
        start_doc = json.loads(start.stdout)
        session_id = start_doc.get("id")
        worktree_value = start_doc.get("worktree_path")
        if not isinstance(session_id, int) or session_id <= 0 or not isinstance(worktree_value, str):
            raise RuntimeError("broker start response lacks a valid session id/worktree_path")
        session_worktree = pathlib.Path(worktree_value).resolve(strict=True)
        try:
            session_worktree.relative_to(worktrees.resolve(strict=True))
        except ValueError as error:
            raise RuntimeError(f"session worktree escaped private worktree root: {session_worktree}") from error
        probe = session_worktree / "schema26-floor-probe.txt"
        write_exclusive(probe, b"Local schema-26 floor probe; no external work.\n")
        result = recorder.git("git-add-session-change", ["add", "--", "schema26-floor-probe.txt"], session_worktree)
        recorder.expect_zero("git-add-session-change", result)
        result = recorder.git("git-commit-session-change", ["commit", "-m", "test(local): create schema floor capture"], session_worktree)
        recorder.expect_zero("git-commit-session-change", result)
        submit = recorder.run(
            "new-broker-submit",
            [new_cli_info["path"], "broker", "submit", "--session", str(session_id), "--json"],
            repo,
        )
        recorder.expect_zero("new-broker-submit", submit)
        submit_doc = json.loads(submit.stdout)
        if submit_doc.get("gate_outcomes") != []:
            raise RuntimeError("synthetic submit unexpectedly selected gate outcomes; no gate run is credited")

        # Confirm the real database metadata through a read-only SQLite URI, and
        # confirm the new binary's public status before asking the old binary.
        current_status = recorder.run(
            "new-collab-status-json",
            [new_cli_info["path"], "collab", "status", "--json", "--repo", str(repo)],
            repo,
        )
        recorder.expect_zero("new-collab-status-json", current_status)
        current_doc = json.loads(current_status.stdout)
        if current_doc.get("config_source") != "committed":
            raise RuntimeError("current CLI did not read the committed legacy .aethyme/config.toml")
        if current_doc.get("project") != PROJECT_KEY:
            raise RuntimeError("current CLI status resolved the wrong project key")
        state_doc = current_doc.get("state", {})
        if state_doc.get("schema_version") != EXPECTED_SCHEMA or state_doc.get("min_compatible_schema") != EXPECTED_FLOOR:
            raise RuntimeError("current CLI status did not report actual schema/floor 26")
        if state_doc.get("refusal"):
            raise RuntimeError("current CLI refused its own schema-26 state")
        project_dir = state / "collaboration" / PROJECT_KEY
        database = project_dir / "state.db"
        db_meta = read_db_meta(database)
        if db_meta != {
            "schema_version": str(EXPECTED_SCHEMA),
            "min_compatible_schema": str(EXPECTED_FLOOR),
            "project_key": PROJECT_KEY,
        }:
            raise RuntimeError(f"read-only DB metadata mismatch: {db_meta}")
        recorder.data["new_cli_state"] = {
            "status_schema": current_doc.get("schema"),
            "config_source": current_doc.get("config_source"),
            "project": current_doc.get("project"),
            "status_state": state_doc,
            "database": str(database),
            "database_sha256_before_old_status": sha256_file(database),
            "database_meta_read_only": db_meta,
            "submit_gate_outcomes": submit_doc.get("gate_outcomes", []),
        }

        # The old-client before/after guard covers every configured mutable root:
        # repository, host state, worktrees, origin, and cache.
        roots = [repo, state, worktrees, origin, cache]
        recorder.data["old_client_snapshot_roots"] = [str(root) for root in roots]
        before, before_sha = recorder.write_snapshot("before-old-client-status", roots)
        recorder.data["before_old_client_snapshot_sha256"] = before_sha

        old_json = recorder.run(
            "old-collab-status-json",
            [old_cli_info["path"], "collab", "status", "--json", "--repo", str(repo)],
            repo,
        )
        recorder.expect_zero("old-collab-status-json", old_json)
        old_doc = json.loads(old_json.stdout)
        refusal = old_doc.get("state", {}).get("refusal", {})
        if old_doc.get("config_source") != "committed":
            raise RuntimeError("old CLI did not read the committed legacy .aethyme/config.toml")
        if refusal.get("code") != "schema_too_new":
            raise RuntimeError(f"old CLI JSON did not refuse schema 26: {refusal}")
        message = refusal.get("message", "")
        if "schema 26" not in message or "supports 23" not in message:
            raise RuntimeError(f"old CLI JSON refusal lacks exact schema/floor message: {message}")
        json_after, json_after_sha = recorder.write_snapshot("after-old-client-json-status", roots)
        if json_after != before:
            raise RuntimeError("old CLI JSON status changed repository/state/worktree/origin/cache bytes")

        old_text = recorder.run(
            "old-collab-status-text",
            [old_cli_info["path"], "collab", "status", "--repo", str(repo)],
            repo,
        )
        recorder.expect_zero("old-collab-status-text", old_text)
        text = old_text.stdout.decode("utf-8", errors="strict")
        if "config: committed .aethyme/config.toml" not in text:
            raise RuntimeError("old CLI text status did not identify the committed legacy config")
        if "state: refused (schema_too_new)" not in text or "schema 26" not in text or "supports 23" not in text:
            raise RuntimeError("old CLI text status did not show the schema-26/schema-23 refusal")
        if "aethyme self-update" not in text:
            raise RuntimeError("old CLI text status did not show its upgrade next action")
        text_after, text_after_sha = recorder.write_snapshot("after-old-client-text-status", roots)
        if text_after != before:
            raise RuntimeError("old CLI text status changed repository/state/worktree/origin/cache bytes")

        source_after = capture_source_git(recorder, source, "source-after")
        if source_after != source_before:
            raise RuntimeError("source head/tree/status or relevant source-file hashes changed")
        new_after = binary_info(new_cli_path)
        old_after = binary_info(PINNED_OLD_CLI, PINNED_OLD_SHA256)
        if new_after != new_cli_info or old_after != old_cli_info:
            raise RuntimeError("one of the exact Aethyme CLI binaries changed during the probe")
        repo_after = git_head_tree(recorder, repo, "playground-after-old-client")
        recorder.data["source_after"] = source_after
        recorder.data["playground_after"] = repo_after
        recorder.data["old_client_refusal"] = {
            "json_exit_status": old_json.returncode,
            "json_schema": old_doc.get("schema"),
            "json_config_source": old_doc.get("config_source"),
            "json_refusal": refusal,
            "text_exit_status": old_text.returncode,
            "text_excerpt": text,
            "before_snapshot_sha256": before_sha,
            "after_json_snapshot_sha256": json_after_sha,
            "after_text_snapshot_sha256": text_after_sha,
            "snapshots_equal": before == json_after == text_after,
            "unchanged_roots": [str(root) for root in roots],
        }
        if repo_after["head"] != repo_before["head"] or repo_after["tree"] != repo_before["tree"]:
            raise RuntimeError("old status changed Playground main HEAD/tree")
        if repo_after["status"]:
            raise RuntimeError("old status left the Playground main worktree dirty")
        final_status = "PASS"
    except Exception as error:
        final_error = f"{type(error).__name__}: {error}"
        recorder.data["partial_command_count"] = len(recorder.command_rows)
    finally:
        if "recorder" in locals():
            try:
                manifest_path = recorder.finish(final_status, final_error)
            except Exception as write_error:
                print(f"failed to write final manifest: {write_error}", file=sys.stderr)

    summary = {
        "status": final_status,
        "run_root": str(run_root),
        "manifest": str(manifest_path) if manifest_path else None,
        "manifest_sha256": sha256_file(manifest_path) if manifest_path and manifest_path.is_file() else None,
        "error": final_error,
    }
    print(json.dumps(summary, sort_keys=True))
    return 0 if final_status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
