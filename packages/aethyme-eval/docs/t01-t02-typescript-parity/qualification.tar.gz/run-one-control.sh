#!/bin/bash
set -u
set -o pipefail

T01_REPO='/Volumes/T7-repositories/Application Support/Aethyme/worktrees/aethyme-6f13a03e16f294c6/implement-t01-rust-typescript-canonical'
T01_PACKAGE='/private/tmp/aethyme-t01-portable-qualification-20261016-004740'
T01_BASE_HEAD='a4b478126edc5f03b84dd8bebc3cedeab7c5947b'
T01_BASE_TREE='daacf68f45a6ab2bce5ece68542bc73ddadfec2c'
T01_NODE='/opt/homebrew/bin/node'
T01_TIMEOUT='/usr/bin/timeout'

case "${1:-}" in
  precision)
    T01_CONTROL='precision'
    T01_TARGET='packages/aethyme-eval/local-v3/t01-canonical-parity/canonical-json.mts'
    T01_BASE_SHA='0b9f582e57d1472abd7e78cb2f2c1e8d9ef2b65ae9ece4d3a4bb0274cb1b2e7f'
    T01_PATCH="$T01_PACKAGE/patches/precision.patch"
    T01_EXPECTED='2^53: expected integer_out_of_range, received accept'
    ;;
  duplicate-key)
    T01_CONTROL='duplicate-key'
    T01_TARGET='packages/aethyme-eval/local-v3/t01-canonical-parity/canonical-json.mts'
    T01_BASE_SHA='0b9f582e57d1472abd7e78cb2f2c1e8d9ef2b65ae9ece4d3a4bb0274cb1b2e7f'
    T01_PATCH="$T01_PACKAGE/patches/duplicate-key.patch"
    T01_EXPECTED='duplicate key: expected duplicate_key, received accept'
    ;;
  set-normalization)
    T01_CONTROL='set-normalization'
    T01_TARGET='packages/aethyme-eval/local-v3/t01-canonical-parity/records.mts'
    T01_BASE_SHA='9f6ddc29981cc67a732886f192ecf46a1eb994dc30fcd91eec1206e709c28bf8'
    T01_PATCH="$T01_PACKAGE/patches/set-normalization.patch"
    T01_EXPECTED='all field kinds: canonical record bytes differ'
    ;;
  raw-paths)
    T01_CONTROL='raw-paths'
    T01_TARGET='packages/aethyme-eval/local-v3/t01-canonical-parity/source-snapshot.mts'
    T01_BASE_SHA='07554ca81e017137a43537f38a58e2c41518ac867ef3369369ed1e1ebd8ef2b3'
    T01_PATCH="$T01_PACKAGE/patches/raw-paths.patch"
    T01_EXPECTED='non-UTF-8 path bytes: source snapshot manifest differs'
    ;;
  brief-budget)
    T01_CONTROL='brief-budget'
    T01_TARGET='packages/aethyme-eval/local-v3/t01-canonical-parity/brief-profile.mts'
    T01_BASE_SHA='b1b5c42a0b8c5f71dcd1482969504a342a0b01333f9237ac3f9dd0ca3ada0628'
    T01_PATCH="$T01_PACKAGE/patches/brief-budget.patch"
    T01_EXPECTED='151 tokens: invalid brief was accepted'
    ;;
  *)
    printf '%s\n' 'usage: run-one-control.sh precision|duplicate-key|set-normalization|raw-paths|brief-budget' >&2
    exit 64
    ;;
esac

T01_RUN_DIR="$T01_PACKAGE/controls/$T01_CONTROL"
T01_BACKUP="$T01_RUN_DIR/pristine-source.mts"
T01_TARGET_ABS="$T01_REPO/$T01_TARGET"
mkdir "$T01_RUN_DIR" || exit 10
cd "$T01_REPO" || exit 11

printf '%s\n' "$T01_CONTROL" > "$T01_RUN_DIR/control-name.txt"
printf '%s\n' "$T01_EXPECTED" > "$T01_RUN_DIR/expected-failure.txt"
printf '%s\n' "$T01_TARGET" > "$T01_RUN_DIR/target-path.txt"
printf '%s\n' "$T01_BASE_SHA" > "$T01_RUN_DIR/expected-pristine-sha256.txt"
printf '%s\n' "$T01_BASE_HEAD" > "$T01_RUN_DIR/expected-head.txt"
printf '%s\n' "$T01_BASE_TREE" > "$T01_RUN_DIR/expected-tree.txt"
printf '%s\n' "$T01_PATCH" > "$T01_RUN_DIR/patch-path.txt"
printf '%s\n' "env -i PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /usr/bin/timeout --signal=TERM --kill-after=5 60 /opt/homebrew/bin/node --max-old-space-size=256 --experimental-strip-types packages/aethyme-eval/local-v3/t01-canonical-parity/t01-canonical-parity.mts" > "$T01_RUN_DIR/command.txt"

# Refuse to begin unless the same clean committed baseline is still checked out.
git rev-parse HEAD > "$T01_RUN_DIR/head-before.txt" || exit 12
git rev-parse 'HEAD^{tree}' > "$T01_RUN_DIR/tree-before.txt" || exit 13
git status --porcelain=v1 > "$T01_RUN_DIR/status-before.txt" || exit 14
read -r T01_RECORDED_HEAD < "$T01_RUN_DIR/head-before.txt"
read -r T01_RECORDED_TREE < "$T01_RUN_DIR/tree-before.txt"
if [ "$T01_RECORDED_HEAD" != "$T01_BASE_HEAD" ] || [ "$T01_RECORDED_TREE" != "$T01_BASE_TREE" ] || [ -s "$T01_RUN_DIR/status-before.txt" ]; then
  printf '%s\n' 'baseline refusal: commit/tree/status mismatch' > "$T01_RUN_DIR/precondition-failure.txt"
  exit 15
fi
shasum -a 256 "$T01_TARGET" > "$T01_RUN_DIR/source-pristine.sha256" || exit 16
read -r T01_ACTUAL_SHA T01_UNUSED_PATH < "$T01_RUN_DIR/source-pristine.sha256"
if [ "$T01_ACTUAL_SHA" != "$T01_BASE_SHA" ]; then
  printf '%s\n' 'baseline refusal: pristine source hash differs' > "$T01_RUN_DIR/precondition-failure.txt"
  exit 17
fi
cp -p "$T01_TARGET_ABS" "$T01_BACKUP" || exit 18
shasum -a 256 "$T01_BACKUP" > "$T01_RUN_DIR/backup.sha256" || exit 19

T01_RESTORE() {
  T01_SCRIPT_EXIT=$?
  trap - EXIT HUP INT TERM
  cp -p "$T01_BACKUP" "$T01_TARGET_ABS" > "$T01_RUN_DIR/restore.stdout" 2> "$T01_RUN_DIR/restore.stderr"
  T01_RESTORE_EXIT=$?
  printf '%s\n' "$T01_RESTORE_EXIT" > "$T01_RUN_DIR/restore-exit.txt"
  shasum -a 256 "$T01_TARGET" > "$T01_RUN_DIR/source-restored.sha256" 2> "$T01_RUN_DIR/restore-hash.stderr"
  T01_RESTORE_HASH_EXIT=$?
  printf '%s\n' "$T01_RESTORE_HASH_EXIT" > "$T01_RUN_DIR/restore-hash-exit.txt"
  git status --porcelain=v1 > "$T01_RUN_DIR/status-after.txt" 2> "$T01_RUN_DIR/status-after.stderr"
  T01_STATUS_EXIT=$?
  printf '%s\n' "$T01_STATUS_EXIT" > "$T01_RUN_DIR/status-after-exit.txt"
  git rev-parse HEAD > "$T01_RUN_DIR/head-after.txt" 2> "$T01_RUN_DIR/head-after.stderr"
  T01_HEAD_EXIT=$?
  git rev-parse 'HEAD^{tree}' > "$T01_RUN_DIR/tree-after.txt" 2> "$T01_RUN_DIR/tree-after.stderr"
  T01_TREE_EXIT=$?
  read -r T01_RESTORED_SHA T01_UNUSED_RESTORED_PATH < "$T01_RUN_DIR/source-restored.sha256"
  if [ "$T01_RESTORE_EXIT" -ne 0 ] || [ "$T01_RESTORE_HASH_EXIT" -ne 0 ] || [ "$T01_STATUS_EXIT" -ne 0 ] || [ "$T01_HEAD_EXIT" -ne 0 ] || [ "$T01_TREE_EXIT" -ne 0 ] || [ "$T01_RESTORED_SHA" != "$T01_BASE_SHA" ] || [ -s "$T01_RUN_DIR/status-after.txt" ]; then
    printf '%s\n' 'restoration verification failed' > "$T01_RUN_DIR/restoration-failure.txt"
    exit 98
  fi
  printf '%s\n' "$T01_SCRIPT_EXIT" > "$T01_RUN_DIR/script-exit.txt"
  exit "$T01_SCRIPT_EXIT"
}
trap T01_RESTORE EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM

"$T01_TIMEOUT" 10 git apply --check "$T01_PATCH" > "$T01_RUN_DIR/patch-check.stdout" 2> "$T01_RUN_DIR/patch-check.stderr"
T01_PATCH_CHECK_EXIT=$?
printf '%s\n' "$T01_PATCH_CHECK_EXIT" > "$T01_RUN_DIR/patch-check-exit.txt"
if [ "$T01_PATCH_CHECK_EXIT" -ne 0 ]; then exit 20; fi
"$T01_TIMEOUT" 10 git apply "$T01_PATCH" > "$T01_RUN_DIR/patch-apply.stdout" 2> "$T01_RUN_DIR/patch-apply.stderr"
T01_PATCH_APPLY_EXIT=$?
printf '%s\n' "$T01_PATCH_APPLY_EXIT" > "$T01_RUN_DIR/patch-apply-exit.txt"
if [ "$T01_PATCH_APPLY_EXIT" -ne 0 ]; then exit 21; fi
shasum -a 256 "$T01_TARGET" > "$T01_RUN_DIR/source-mutant.sha256" 2> "$T01_RUN_DIR/mutant-hash.stderr"
printf '%s\n' "$?" > "$T01_RUN_DIR/mutant-hash-exit.txt"
git status --porcelain=v1 > "$T01_RUN_DIR/status-mutant.txt" 2> "$T01_RUN_DIR/status-mutant.stderr"
printf '%s\n' "$?" > "$T01_RUN_DIR/status-mutant-exit.txt"
git diff --binary -- "$T01_TARGET" > "$T01_RUN_DIR/applied-diff.patch" 2> "$T01_RUN_DIR/applied-diff.stderr"
printf '%s\n' "$?" > "$T01_RUN_DIR/applied-diff-exit.txt"

set +e
env -i PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin "$T01_TIMEOUT" --signal=TERM --kill-after=5 60 "$T01_NODE" --max-old-space-size=256 --experimental-strip-types packages/aethyme-eval/local-v3/t01-canonical-parity/t01-canonical-parity.mts > "$T01_RUN_DIR/stdout.log" 2> "$T01_RUN_DIR/stderr.log"
T01_NODE_EXIT=$?
printf '%s\n' "$T01_NODE_EXIT" > "$T01_RUN_DIR/node-exit.txt"
grep -F "$T01_EXPECTED" "$T01_RUN_DIR/stderr.log" > "$T01_RUN_DIR/expected-failure-match.txt" 2>&1
T01_EXPECTED_MATCH_EXIT=$?
printf '%s\n' "$T01_EXPECTED_MATCH_EXIT" > "$T01_RUN_DIR/expected-failure-match-exit.txt"
exit 0
