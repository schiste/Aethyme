# Proposed T01/T02 offline mutation controls — review only

No mutant patch has been applied or executed. These controls are proposed for
review against the positive-qualified baseline only.

## Baseline

- Commit: `a4b478126edc5f03b84dd8bebc3cedeab7c5947b`
- Tree: `daacf68f45a6ab2bce5ece68542bc73ddadfec2c`
- Positive run: `/private/tmp/aethyme-t01-positive-20261016-004213`
- Command: `/usr/bin/timeout --signal=TERM --kill-after=5 60 node --max-old-space-size=256 --experimental-strip-types packages/aethyme-eval/local-v3/t01-canonical-parity/t01-canonical-parity.mts`
- Runtime: Node v26.8.2, `/opt/homebrew/bin/node`
- All five TypeScript source hashes and all 14 frozen Rust fixture/test/source hashes matched before/after the positive run.

## Control 1 — safe integer precision guard

Target: `packages/aethyme-eval/local-v3/t01-canonical-parity/canonical-json.mts`

Baseline SHA-256: `0b9f582e57d1472abd7e78cb2f2c1e8d9ef2b65ae9ece4d3a4bb0274cb1b2e7f`

Patch:

```diff
-    if (magnitude > MAX_SAFE_INTEGER_BIGINT) {
+    if (false && magnitude > MAX_SAFE_INTEGER_BIGINT) {
```

Expected first intended assertion failure:

```text
2^53: expected integer_out_of_range, received accept
```

## Control 2 — duplicate-key guard

Target: `packages/aethyme-eval/local-v3/t01-canonical-parity/canonical-json.mts`

Baseline SHA-256: `0b9f582e57d1472abd7e78cb2f2c1e8d9ef2b65ae9ece4d3a4bb0274cb1b2e7f`

Patch:

```diff
-        if (object.has(memberName)) {
+        if (false && object.has(memberName)) {
```

Expected first intended assertion failure:

```text
duplicate key: expected duplicate_key, received accept
```

## Control 3 — unordered string-set normalization

Target: `packages/aethyme-eval/local-v3/t01-canonical-parity/records.mts`

Baseline SHA-256: `9f6ddc29981cc67a732886f192ecf46a1eb994dc30fcd91eec1206e709c28bf8`

Patch:

```diff
-  const sorted = [...value].sort((left, right) =>
-    compareUtf16(left as string, right as string),
-  ) as string[];
+  const sorted = [...value] as string[];
```

The frozen `all field kinds` record supplies `paths` as `["src/b.rs", "src/a.rs"]`, so preserving input order violates the canonical set order.

Expected first intended assertion failure:

```text
all field kinds: canonical record bytes differ
```

## Control 4 — raw path byte preservation

Target: `packages/aethyme-eval/local-v3/t01-canonical-parity/source-snapshot.mts`

Baseline SHA-256: `07554ca81e017137a43537f38a58e2c41518ac867ef3369369ed1e1ebd8ef2b3`

Patch:

```diff
-    const path = decodeHex(vector.path_hex);
+    const path = Buffer.from(decodeHex(vector.path_hex).toString("utf8"), "utf8");
```

This deliberately loses the raw `0xe9` byte in the frozen non-UTF-8 path vector by decoding through replacement text.

Expected first intended assertion failure:

```text
non-UTF-8 path bytes: source snapshot manifest differs
```

## Control 5 — brief token-budget guard

Target: `packages/aethyme-eval/local-v3/t01-canonical-parity/brief-profile.mts`

Baseline SHA-256: `b1b5c42a0b8c5f71dcd1482969504a342a0b01333f9237ac3f9dd0ca3ada0628`

Patch:

```diff
-  if (tokens > BRIEF_LIMITS.max_tokens) {
+  if (false && tokens > BRIEF_LIMITS.max_tokens) {
```

Expected first intended assertion failure:

```text
151 tokens: invalid brief was accepted
```

## Execution and accounting proposal

If approved, apply one patch per run to the committed baseline. For each control,
create a unique pristine source backup outside the repository, verify its hash,
and install an EXIT/HUP/INT/TERM restoration trap before changing the source.
Capture the exact patch, command, full stdout, full stderr, numeric Node/timeout
exit status, pre/post source SHA-256, baseline commit/tree, and worktree status.
After every run, restore from the backup and verify the source SHA-256 exactly
matches the baseline. Only the listed intended named assertion failure counts;
compile/loader errors, timeouts, zero exit, or any other first failure are
retained but uncredited. After all controls, run one fresh positive qualification
from the restored source with the same 256 MiB cap and 60-second deadline, and
verify all hashes/status/HEAD again. No golden vector, Rust source, or harness
assertion is changed for a control.
