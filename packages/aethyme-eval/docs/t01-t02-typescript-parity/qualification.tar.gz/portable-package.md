# Offline T01/T02 TypeScript parity qualification package

This package contains immutable copies of the exact TypeScript harness/modules, frozen Rust fixture vectors and Rust reference sources used for the offline qualification. `frozen-inputs/source-sha256.txt` records hashes using repository-relative paths. All original attempt logs, full stdout/stderr, exit statuses, source restoration data, and mutant patches are preserved under `attempts/`, `controls/`, `patches/`, and `preflight-patch-checks/`; no earlier attempt was overwritten.

## Qualification result

- Baseline: commit `a4b478126edc5f03b84dd8bebc3cedeab7c5947b`, tree `daacf68f45a6ab2bce5ece68542bc73ddadfec2c`.
- Runtime: Node v26.8.2, `/opt/homebrew/bin/node`, binary SHA-256 `3e401401d90e7f0367b7737a613801242c9a6b2966fb50c2e48eb1c45d701c6a`; arm64 Mach-O symlink to Homebrew Cellar 26.8.2. Runtime provenance and symlink details are in `runtime-provenance.txt`, `node-binary.file.txt`, and `node-binary.ls.txt`.
- Harness invocation: clean PATH and environment, `--max-old-space-size=256`, `/usr/bin/timeout` with a 60-second deadline and TERM/KILL grace, Node type stripping, no Cargo/native code, Docker, network, install, or providers.
- Restored positive run: `attempts/restored-positive`; exit 0, status `pass`, 880 assertions, empty stderr. The pinned source/fixture hashes, HEAD/tree, and clean status matched before and after.
- Mutant controls: five independently reviewed controls; each produced its exact named first assertion failure, exit 1, empty stdout, and exact source restoration with clean status and unchanged HEAD/tree. See each directory under `controls/` for command, full output, patches, mutant/pristine/restored hashes, and status metadata.
- Earlier run history is retained: `attempts/first-positive-failed` is an uncredited behavioral failure before the brief-token parity fix; `attempts/positive-clean` is the positive before controls; `preflight-patch-checks/attempt1` and `attempt2` preserve two corrected-before-execution patch-preflight attempts. These are included for complete accounting.

## Scope

This is a finite offline contract parity qualification against existing frozen Rust-generated vectors, not an Aethyme evaluation target or production TypeScript consumer. No golden vectors or Rust contract code were edited to fit the TypeScript implementation. No dependencies or external assets were added.
