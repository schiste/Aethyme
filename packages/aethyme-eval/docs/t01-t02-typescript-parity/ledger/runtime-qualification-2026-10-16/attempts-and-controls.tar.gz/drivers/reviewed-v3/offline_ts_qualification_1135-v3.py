#!/usr/bin/env python3
"""Offline T01/T02 + D10 qualification and reviewed guard controls.

DO NOT RUN until the coordinator grants runtime after independent static review.
The script enforces exact frozen HEAD/tree, clean state, Node binary, 256 MiB heap,
60-second per-process deadline, source pins, exact mutation patches, and byte-exact
finally restoration. It never changes fixtures/oracles; it launches only local
read-only Git metadata commands and Node harnesses.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import signal
import subprocess
import sys
import tempfile
import time
from typing import Any

ROOT = Path('/Volumes/T7-repositories/Application Support/Aethyme/worktrees/aethyme-6f13a03e16f294c6/add-finite-d10-typescript-parity-for-pro').resolve()
NODE = Path('/opt/homebrew/bin/node')
EXPECTED_HEAD = 'd7b34d65435222bdf3a60e2a15e038364a6ec6f2'
EXPECTED_TREE = '43f9c94a66718a177ff4ed3c2095f02df99a553b'
EXPECTED_BRANCH = 'agent/add-finite-d10-typescript-parity-for-pro'
EXPECTED_RUST_SOURCE_COMMIT = 'e6fb95f65f3bf91d46c1ab76136486f492529ebb'
EXPECTED_FIXTURE_SOURCE_COMMIT = 'fcd5ed940b4d906452e4ad1d3aa90eb767f1af45'
D10 = Path('packages/aethyme-eval/local-v3/d10-identity-parity')
T01_RUNNER = Path('packages/aethyme-eval/local-v3/t01-canonical-parity/t01-canonical-parity.mts')
D10_RUNNER = D10 / 'd10-identity-parity.mts'
PIN_FILE = D10 / 'source-pins.json'
CANONICAL = Path('packages/aethyme-eval/local-v3/t01-canonical-parity/canonical-json.mts')
IDENTITY = D10 / 'project-identity.mts'
MAX_HEAP_MIB = 256
DEADLINE_SECONDS = 60
SAFE_PATH = '/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'

CONTROLS = [
    {
        'id': '01-early-reference-count',
        'source': IDENTITY,
        'old': 'if (!(change instanceof Map)) continue;',
        'new': 'if (!(change instanceof Map) || !(change.get("after") instanceof Map)) continue;',
        'expected_assertion': 'ContributionRevision scans oversized reference arrays before malformed change semantics',
    },
    {
        'id': '02-brief-digest-precedence',
        'source': IDENTITY,
        'old': 'args.brief_object_sha256 !== undefined &&',
        'new': 'false && args.brief_object_sha256 !== undefined &&',
        'expected_assertion': 'ContributionRevision validates the borrowed brief digest before change semantics',
    },
    {
        'id': '03-full-envelope-cap',
        'source': IDENTITY,
        'old': 'if (boundedCanonicalByteLength(sizeFields) === undefined) {',
        'new': 'if (false && boundedCanonicalByteLength(sizeFields) === undefined) {',
        'expected_assertion': 'ContributionRevision rejects an oversized full envelope before malformed change semantics',
    },
    {
        'id': '04-raw-path-predecode-cap',
        'source': IDENTITY,
        'old': '  if (pathHex.length > MAX_PATH_BYTES * 2) fail("invalid_source_change");\n',
        'new': '',
        'expected_assertion': 'ContributionRevision rejects path_hex over the raw-path cap before decoding',
    },
    {
        'id': '05-utf8-byte-count',
        'source': CANONICAL,
        'old': 'else if (codePoint <= 0x7ff) scalarBytes = 2;',
        'new': 'else if (codePoint <= 0x7ff) scalarBytes = 1;',
        'expected_assertion': 'bounded canonical size counts a two-byte UTF-8 scalar at the exact limit',
    },
    {
        'id': '06-newline-escape-byte-count',
        'source': CANONICAL,
        'old': '      codePoint === 0x0a ||\n',
        'new': '',
        'expected_assertion': 'bounded canonical size counts newline escaping at the exact limit',
    },
]

class StopRequested(BaseException):
    pass

STOP_REQUESTED: int | None = None
ACTIVE_CHILD: subprocess.Popen[bytes] | None = None

def handle_stop(signum: int, frame: Any) -> None:
    """Record the signal and terminate only the direct, tracked child.

    Never raise from the handler: a signal must not interrupt byte restoration
    or interrupt the child's communicate/cleanup sequence.
    """
    global STOP_REQUESTED
    if STOP_REQUESTED is None:
        STOP_REQUESTED = signum
    child = ACTIVE_CHILD
    if child is not None:
        try:
            child.terminate()
        except OSError:
            pass

def raise_if_stop_requested() -> None:
    if STOP_REQUESTED is not None:
        raise StopRequested(f'received signal {STOP_REQUESTED}; active control restored before exit')

signal.signal(signal.SIGINT, handle_stop)
signal.signal(signal.SIGTERM, handle_stop)

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def sha_file(path: Path) -> str:
    return sha256(path.read_bytes())

def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')

def safe_env(tmp: Path | None = None) -> dict[str, str]:
    env = {'PATH': SAFE_PATH, 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC'}
    if tmp is not None:
        env['TMPDIR'] = str(tmp)
    return env

def git(*args: str) -> str:
    completed = subprocess.run(
        ['git', '-C', str(ROOT), *args],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={**safe_env(), 'GIT_OPTIONAL_LOCKS': '0'},
        timeout=DEADLINE_SECONDS,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(f'git {args!r} exited {completed.returncode}: {completed.stderr.decode("utf-8", "replace")}')
    return completed.stdout.decode('utf-8', 'strict').rstrip('\n')

def status_paths() -> list[str]:
    raw = git('status', '--porcelain=v1', '--untracked-files=all')
    return [line[3:] for line in raw.splitlines() if line]

def verify_checkout(require_clean: bool) -> dict[str, Any]:
    head = git('rev-parse', 'HEAD')
    tree = git('rev-parse', 'HEAD^{tree}')
    branch = git('branch', '--show-current')
    dirty = status_paths()
    result = {'head': head, 'tree': tree, 'branch': branch, 'status_paths': dirty}
    if head != EXPECTED_HEAD or tree != EXPECTED_TREE or branch != EXPECTED_BRANCH:
        raise RuntimeError(f'frozen checkout mismatch: {result}')
    if require_clean and dirty:
        raise RuntimeError(f'checkout must be clean before/after positive run: {dirty}')
    return result

def pin_inventory() -> dict[str, Any]:
    pin_path = ROOT / PIN_FILE
    raw = pin_path.read_bytes()
    pins = json.loads(raw)
    if pins.get('schema') != 'aethyme.local-d10-typescript-parity-pins/v2':
        raise RuntimeError('unsupported source pin manifest schema')
    if pins.get('qualification_source_commit') != EXPECTED_RUST_SOURCE_COMMIT:
        raise RuntimeError('Rust qualification commit does not match reviewed checkpoint')
    if pins.get('fixture_source_commit') != EXPECTED_FIXTURE_SOURCE_COMMIT:
        raise RuntimeError('independent fixture source commit changed')
    groups = [('rust_sources', 12), ('typescript_sources', 3), ('fixture_files', 20)]
    rows: list[dict[str, Any]] = []
    for name, count in groups:
        entries = pins.get(name)
        if not isinstance(entries, list) or len(entries) != count:
            raise RuntimeError(f'{name} must contain exactly {count} paths')
        for entry in entries:
            rel = Path(entry['path'])
            if rel.is_absolute() or '..' in rel.parts:
                raise RuntimeError(f'unsafe pinned path: {entry["path"]}')
            path = (ROOT / rel) if name != 'fixture_files' else (ROOT / D10 / rel)
            actual = sha_file(path)
            rows.append({
                'group': name,
                'path': entry['path'],
                'expected_sha256': entry['sha256'],
                'actual_sha256': actual,
                'matches': actual == entry['sha256'],
            })
    mismatches = [row for row in rows if not row['matches']]
    if mismatches:
        raise RuntimeError(f'{len(mismatches)} source/fixture pins mismatch: {mismatches}')
    return {
        'source_pins_sha256': sha256(raw),
        'qualification_source_commit': pins['qualification_source_commit'],
        'fixture_source_commit': pins['fixture_source_commit'],
        'counts': {name: count for name, count in groups},
        'entries': rows,
    }

def capture_process(name: str, argv: list[str], folder: Path, deadline: int = DEADLINE_SECONDS) -> dict[str, Any]:
    raise_if_stop_requested()
    folder.mkdir(parents=True, exist_ok=False)
    started_at = dt.datetime.now(dt.timezone.utc).isoformat()
    start = time.monotonic()
    timed_out = False
    launch_error = None
    returncode: int | None = None
    stdout = b''
    stderr = b''
    proc: subprocess.Popen[bytes] | None = None
    deferred_error: BaseException | None = None
    global ACTIVE_CHILD
    try:
        proc = subprocess.Popen(
            argv,
            cwd=ROOT,
            env=safe_env(folder),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=False,
            close_fds=True,
        )
        ACTIVE_CHILD = proc
        if STOP_REQUESTED is not None and proc.poll() is None:
            try:
                proc.terminate()
            except OSError:
                pass
        try:
            stdout, stderr = proc.communicate(timeout=deadline)
            returncode = proc.returncode
        except subprocess.TimeoutExpired:
            timed_out = True
            if proc.poll() is None:
                try:
                    proc.terminate()
                except ProcessLookupError:
                    pass
            try:
                stdout, stderr = proc.communicate(timeout=3)
            except subprocess.TimeoutExpired:
                # Only this directly launched Node PID is terminated; no process-name kill.
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
                stdout, stderr = proc.communicate()
            returncode = proc.returncode
        except BaseException as error:
            deferred_error = error
            if proc.poll() is None:
                try:
                    proc.terminate()
                except ProcessLookupError:
                    pass
                try:
                    stdout, stderr = proc.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    try:
                        proc.kill()
                    except ProcessLookupError:
                        pass
                    stdout, stderr = proc.communicate()
            else:
                stdout, stderr = proc.communicate()
            returncode = proc.returncode
    except OSError as error:
        launch_error = f'{type(error).__name__}: {error}'
    except BaseException as error:
        deferred_error = error
    finally:
        if ACTIVE_CHILD is proc:
            ACTIVE_CHILD = None
    elapsed = time.monotonic() - start
    (folder / 'stdout.bin').write_bytes(stdout)
    (folder / 'stderr.bin').write_bytes(stderr)
    record = {
        'name': name,
        'argv': argv,
        'cwd': str(ROOT),
        'environment_allowlist': safe_env(folder),
        'deadline_seconds': deadline,
        'started_at_utc': started_at,
        'elapsed_seconds': elapsed,
        'timed_out': timed_out,
        'numeric_exit_status': returncode,
        'launch_error': launch_error,
        'deferred_error': f'{type(deferred_error).__name__}: {deferred_error}' if deferred_error else None,
        'stdout_bytes': len(stdout),
        'stderr_bytes': len(stderr),
        'stdout_sha256': sha256(stdout),
        'stderr_sha256': sha256(stderr),
        'stdout_path': 'stdout.bin',
        'stderr_path': 'stderr.bin',
    }
    write_json(folder / 'status.json', record)
    if deferred_error is not None:
        raise deferred_error
    raise_if_stop_requested()
    return {**record, 'stdout': stdout, 'stderr': stderr}

def node_argv(script: Path, *extra: str) -> list[str]:
    return [str(NODE), f'--max-old-space-size={MAX_HEAP_MIB}', '--experimental-strip-types', *extra, str(script)]

def parse_json_report(run: dict[str, Any]) -> dict[str, Any] | None:
    try:
        value = json.loads(run['stdout'].decode('utf-8', 'strict'))
        return value if isinstance(value, dict) else None
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None

def evaluate_pair(pair: dict[str, Any], inventory: dict[str, Any]) -> dict[str, Any]:
    t01 = pair['t01']
    d10 = pair['d10']
    t01_report = parse_json_report(t01)
    d10_report = parse_json_report(d10)
    t01_ok = bool(
        t01['numeric_exit_status'] == 0 and not t01['timed_out'] and t01_report is not None
        and t01_report.get('schema') == 'aethyme.local-v3.t01-t02-typescript-parity.v1'
        and t01_report.get('status') == 'pass' and t01_report.get('assertions') == 880
    )
    expected_verified = {
        (row['path'], row['actual_sha256'])
        for row in inventory['entries']
    }
    d10_verified = set()
    if d10_report is not None and isinstance(d10_report.get('verified_files'), list):
        d10_verified = {
            (row.get('path'), row.get('sha256'))
            for row in d10_report['verified_files'] if isinstance(row, dict)
        }
    d10_ok = bool(
        d10['numeric_exit_status'] == 0 and not d10['timed_out'] and d10_report is not None
        and d10_report.get('schema') == 'aethyme.local-d10-typescript-parity-report/v1'
        and type(d10_report.get('assertions')) is int and d10_report['assertions'] > 0
        and d10_report.get('qualification_source_commit') == EXPECTED_RUST_SOURCE_COMMIT
        and d10_report.get('fixture_source_commit') == EXPECTED_FIXTURE_SOURCE_COMMIT
        and d10_report.get('source_pins_sha256') == inventory['source_pins_sha256']
        and d10_report.get('pin_counts') == {'rust_sources': 12, 'typescript_sources': 3, 'frozen_fixture_files': 20}
        and len(d10_verified) == 35 and d10_verified == expected_verified
    )
    return {
        't01_t02': {'pass': t01_ok, 'assertions': t01_report.get('assertions') if t01_report else None,
                    'schema': t01_report.get('schema') if t01_report else None,
                    'vectors': t01_report.get('vectors') if t01_report else None},
        'd10': {'pass': d10_ok, 'assertions': d10_report.get('assertions') if d10_report else None,
                'schema': d10_report.get('schema') if d10_report else None,
                'pin_counts': d10_report.get('pin_counts') if d10_report else None,
                'verified_file_count': len(d10_verified), 'vectors': d10_report.get('vectors') if d10_report else None},
        'pass': t01_ok and d10_ok,
    }

def run_pair(label: str, out: Path, inventory: dict[str, Any]) -> dict[str, Any]:
    pair_dir = out / label
    pair_dir.mkdir(parents=True, exist_ok=False)
    t01 = capture_process('T01/T02 frozen canonical-record-snapshot-brief parity',
                          node_argv(T01_RUNNER), pair_dir / 't01-t02')
    d10 = capture_process('D10 frozen identity-contribution parity',
                          node_argv(D10_RUNNER), pair_dir / 'd10')
    evaluation = evaluate_pair({'t01': t01, 'd10': d10}, inventory)
    write_json(pair_dir / 'evaluation.json', evaluation)
    return {'directory': str(pair_dir), 'evaluation': evaluation}

def replace_once(source_bytes: bytes, old: str, new: str) -> bytes:
    source = source_bytes.decode('utf-8', 'strict')
    if source.count(old) != 1:
        raise RuntimeError(f'mutation patch must match exactly once; found {source.count(old)} for {old!r}')
    return source.replace(old, new, 1).encode('utf-8')

def update_only_typescript_pin(pin_bytes: bytes, rel_source: Path, new_digest: str) -> bytes:
    text = pin_bytes.decode('utf-8', 'strict')
    before = json.loads(text)
    path = rel_source.as_posix()
    entries = before['typescript_sources']
    matches = [entry for entry in entries if entry.get('path') == path]
    if len(matches) != 1:
        raise RuntimeError(f'expected exactly one TypeScript source pin for {path}')
    old_digest = matches[0]['sha256']
    pattern = re.compile(r'("path":\s*' + re.escape(json.dumps(path)) + r',\s*"sha256":\s*")[0-9a-f]{64}(")')
    # JSON formatting uses path then sha256; keep all manifest bytes except this digest.
    found = list(pattern.finditer(text))
    if len(found) != 1:
        raise RuntimeError(f'expected one serialized digest field for {path}; found {len(found)}')
    match = found[0]
    updated = text[:match.start()] + match.group(1) + new_digest + match.group(2) + text[match.end():]
    after = json.loads(updated)
    before_hashes = {entry['path']: entry['sha256'] for entry in before['typescript_sources']}
    after_hashes = {entry['path']: entry['sha256'] for entry in after['typescript_sources']}
    if set(before_hashes) != set(after_hashes):
        raise RuntimeError('TypeScript path set changed while mutating one source pin')
    if {key: val for key, val in before_hashes.items() if key != path} != {key: val for key, val in after_hashes.items() if key != path}:
        raise RuntimeError('a TypeScript pin other than the mutated source changed')
    if after_hashes.get(path) != new_digest or before_hashes.get(path) != old_digest:
        raise RuntimeError('mutated TypeScript pin does not match exact source digest')
    return updated.encode('utf-8')

def run_control(control: dict[str, Any], out: Path, source_original: bytes, pins_original: bytes) -> dict[str, Any]:
    folder = out / control['id']
    folder.mkdir(parents=True, exist_ok=False)
    source_path = ROOT / control['source']
    pin_path = ROOT / PIN_FILE
    backup_dir = Path(tempfile.mkdtemp(prefix='pristine-backup-', dir=folder))
    source_backup = backup_dir / 'source.bytes'
    pins_backup = backup_dir / 'source-pins.json'
    source_backup.write_bytes(source_original)
    pins_backup.write_bytes(pins_original)
    before_hashes = {'source': sha256(source_original), 'source_pins': sha256(pins_original)}
    backup_files = {
        'source': {'path': str(source_backup), 'bytes': source_backup.stat().st_size, 'sha256': sha_file(source_backup)},
        'source_pins': {'path': str(pins_backup), 'bytes': pins_backup.stat().st_size, 'sha256': sha_file(pins_backup)},
    }
    if (source_backup.read_bytes() != source_original or pins_backup.read_bytes() != pins_original
            or backup_files['source']['sha256'] != before_hashes['source']
            or backup_files['source_pins']['sha256'] != before_hashes['source_pins']):
        raise RuntimeError('unique control backup bytes do not match the frozen originals')
    result: dict[str, Any] = {'id': control['id'], 'expected_assertion': control['expected_assertion'],
                              'source_path': control['source'].as_posix(), 'backup_dir': str(backup_dir),
                              'backup_hashes': before_hashes, 'backup_files': backup_files,
                              'process_status_dir': str(folder / 'd10'),
                              'executed': False, 'credited': False}
    try:
        raise_if_stop_requested()
        if source_path.read_bytes() != source_original or pin_path.read_bytes() != pins_original:
            raise RuntimeError('control baseline bytes changed before mutation')
        mutant = replace_once(source_original, control['old'], control['new'])
        source_path.write_bytes(mutant)
        mutant_sha = sha256(mutant)
        new_pin_bytes = update_only_typescript_pin(pins_original, control['source'], mutant_sha)
        pin_path.write_bytes(new_pin_bytes)
        inventory = pin_inventory()
        if len(inventory['entries']) != 35:
            raise RuntimeError('mutant preflight did not verify all 35 source/input pins')
        dirty = set(status_paths())
        expected_dirty = {control['source'].as_posix(), PIN_FILE.as_posix()}
        if dirty != expected_dirty:
            raise RuntimeError(f'mutant changed an unexpected path: {sorted(dirty)}')
        result['mutant_sha256'] = mutant_sha
        result['mutant_source_pins_sha256'] = inventory['source_pins_sha256']
        result['mutant_pin_matches'] = True
        result['executed'] = True
        run = capture_process(control['id'], node_argv(D10_RUNNER), folder / 'd10')
        combined = run['stdout'] + b'\n' + run['stderr']
        expected_error = ('Error: ' + control['expected_assertion']).encode('utf-8')
        forbidden = [b'SyntaxError', b'ERR_MODULE_NOT_FOUND', b'ERR_UNSUPPORTED_TYPESCRIPT_SYNTAX',
                     b'Cannot find module', b'Cannot find package']
        result['process'] = {key: run[key] for key in ('argv', 'elapsed_seconds', 'timed_out',
                                  'numeric_exit_status', 'launch_error', 'stdout_bytes', 'stderr_bytes',
                                  'stdout_sha256', 'stderr_sha256')}
        result['expected_error_string_found'] = (
            expected_error in run['stderr'] and combined.count(expected_error) == 1
        )
        result['forbidden_preflight_or_compile_error'] = any(marker in combined for marker in forbidden)
        result['credited'] = bool(type(run['numeric_exit_status']) is int
                                  and run['numeric_exit_status'] == 1 and not run['timed_out']
                                  and run['launch_error'] is None and result['expected_error_string_found']
                                  and not result['forbidden_preflight_or_compile_error'])
        result['classification'] = 'intended_named_assertion_failure' if result['credited'] else 'uncredited_failure_or_unexpected_pass'
    except StopRequested:
        raise
    except BaseException as error:
        result['control_error'] = f'{type(error).__name__}: {error}'
        result['classification'] = 'uncredited_control_setup_or_execution_error'
    finally:
        # The signal handler only records signals, so they cannot interrupt this
        # exact-byte restoration or the subsequent evidence write.
        restore_errors: list[str] = []
        for path, original in ((source_path, source_original), (pin_path, pins_original)):
            try:
                path.write_bytes(original)
            except BaseException as error:
                restore_errors.append(f'{path}: {type(error).__name__}: {error}')
        result['restore_errors'] = restore_errors
        try:
            restored = {'source': sha_file(source_path), 'source_pins': sha_file(pin_path)}
            exact_restore = (
                not restore_errors and restored == before_hashes
                and source_path.read_bytes() == source_original
                and pin_path.read_bytes() == pins_original
            )
        except BaseException as error:
            restored = {}
            exact_restore = False
            result['restore_errors'].append(f'readback: {type(error).__name__}: {error}')
        result['restored_hashes'] = restored
        result['exact_restore'] = exact_restore
        result['stop_requested_signal'] = STOP_REQUESTED
        try:
            result['restored_git_status_paths'] = status_paths()
        except BaseException as error:
            result['restored_git_status_paths'] = None
            result['restore_errors'].append(f'git status readback: {type(error).__name__}: {error}')
        result['restoration_clean'] = (
            result['exact_restore'] and result['restored_git_status_paths'] == []
        )
        if STOP_REQUESTED is not None and not result.get('classification'):
            result['classification'] = 'interrupted_stop_restored'
        result['credited'] = result['credited'] and result['restoration_clean']
        if not result['restoration_clean']:
            result['classification'] = 'uncredited_restore_mismatch_or_dirty_checkout'
        write_json(folder / 'control-status.json', result)
        raise_if_stop_requested()
    return result

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-after-independent-review-and-coordinator-runtime-grant', action='store_true',
                        help='required acknowledgment; this script must not run before both gates')
    parser.add_argument('--output-parent', type=Path, default=Path('/private/tmp'))
    args = parser.parse_args()
    if not args.run_after_independent_review_and_coordinator_runtime_grant:
        parser.error('runtime acknowledgment flag is mandatory; no Node process was started')
    raise_if_stop_requested()
    if args.output_parent.resolve() != Path('/private/tmp'):
        parser.error('artifacts must remain under /private/tmp')
    before = verify_checkout(require_clean=True)
    raise_if_stop_requested()
    inventory = pin_inventory()
    if len(inventory['entries']) != 35:
        raise RuntimeError('expected 35 independently pinned source/input files')
    raise_if_stop_requested()
    if not NODE.is_file():
        raise RuntimeError(f'fixed Node executable is unavailable: {NODE}')
    out = Path(tempfile.mkdtemp(prefix='aethyme-ts1135-qualified-', dir='/private/tmp'))
    source_originals = {path: (ROOT / path).read_bytes() for path in (IDENTITY, CANONICAL)}
    pins_original = (ROOT / PIN_FILE).read_bytes()
    node_realpath = NODE.resolve(strict=True)
    node_hash_before = sha_file(node_realpath)
    identity = capture_process('Node runtime version',
                               [str(NODE), f'--max-old-space-size={MAX_HEAP_MIB}', '--version'], out / 'node-version')
    if identity['numeric_exit_status'] != 0 or identity['timed_out']:
        raise RuntimeError('could not record bounded Node version')
    version = identity['stdout'].decode('utf-8', 'replace').strip()
    write_json(out / 'start.json', {
        'worktree': before, 'source_pin_inventory': inventory, 'source_pins_file_sha256': inventory['source_pins_sha256'],
        'node_path_requested': str(NODE), 'node_realpath': str(node_realpath),
        'node_binary_sha256': node_hash_before, 'node_version': version,
        'qualification_driver_sha256': sha_file(Path(__file__).resolve()),
        'heap_mib': MAX_HEAP_MIB, 'per_process_deadline_seconds': DEADLINE_SECONDS,
        'commands_scope': ['local Git metadata reads', 'Node runtime version', 'T01/T02 runner', 'D10 runner'],
        'network_or_install_commands': False, 'cargo_or_native_commands': False,
        'provider_or_heldout_calls': False, 'fixture_or_oracle_mutation': False,
    })
    initial = run_pair('initial-positive', out, inventory)
    results: dict[str, Any] = {'initial_positive': initial, 'controls': [], 'restored_positive': None}
    if not initial['evaluation']['pass']:
        results['controls_skipped'] = 'baseline did not pass both T01/T02=880 and D10 pinned report checks'
        results['overall_status'] = 'UNQUALIFIED_BASELINE_FAILURE'
    else:
        for control in CONTROLS:
            result = run_control(control, out / 'controls', source_originals[control['source']], pins_original)
            results['controls'].append(result)
            raise_if_stop_requested()
        current_inventory = pin_inventory()
        if current_inventory != inventory:
            raise RuntimeError('source/input pins differ from the exact pristine inventory after restoration')
        if status_paths():
            raise RuntimeError(f'checkout is not clean after controls: {status_paths()}')
        restored = run_pair('restored-positive', out, current_inventory)
        results['restored_positive'] = restored
        all_controls_credited = len(results['controls']) == len(CONTROLS) and all(item['credited'] for item in results['controls'])
        results['overall_status'] = 'PASS' if restored['evaluation']['pass'] and all_controls_credited else 'UNQUALIFIED_CONTROL_OR_RESTORE_FAILURE'
    after = verify_checkout(require_clean=True)
    raise_if_stop_requested()
    node_hash_after = sha_file(node_realpath)
    if node_hash_after != node_hash_before:
        results['overall_status'] = 'UNQUALIFIED_NODE_BINARY_CHANGED'
    results['end'] = {'worktree': after, 'node_binary_sha256': node_hash_after,
                      'source_pins_sha256': sha_file(ROOT / PIN_FILE)}
    results['attempt_log_root'] = str(out)
    write_json(out / 'qualification-results.json', results)
    print(json.dumps({'attempt_log_root': str(out), 'overall_status': results['overall_status'],
                      't01_t02_assertions': (initial['evaluation']['t01_t02']['assertions']),
                      'd10_assertions': (initial['evaluation']['d10']['assertions']),
                      'controls_credited': sum(1 for item in results['controls'] if item['credited']),
                      'control_count': len(CONTROLS),
                      'restored_positive_pass': bool(results['restored_positive'] and results['restored_positive']['evaluation']['pass'])}, indent=2))
    return 0 if results['overall_status'] == 'PASS' else 1

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except StopRequested as stopped:
        print(str(stopped), file=sys.stderr)
        raise SystemExit(130)
